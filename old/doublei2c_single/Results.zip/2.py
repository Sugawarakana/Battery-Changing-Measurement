
import numpy as np
cap_values = []
with open('1.txt', encoding='utf-8') as f:
    for line in f:
        if ':' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
# variance = np.var(cap_values)
# print(f"Variance: {variance}")
m = np.mean(cap_values)
print(f"mean: {m}")