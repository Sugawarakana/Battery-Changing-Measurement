import matplotlib.pyplot as plt
import numpy as np

cap_values = []
with open('Results\\2chips_2channels_single_conversion\cap0_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance0:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance0 (pF)')
plt.title('Capacitance0 Data')
plt.grid(True)
plt.show()

cap_values = []
with open('Results\\2chips_2channels_single_conversion\cap1_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance1:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance1 (pF)')
plt.title('Capacitance1 Data')
plt.grid(True)
plt.show()

cap_values = []
with open('Results\\2chips_2channels_single_conversion\cap2_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance2:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance2 (pF)')
plt.title('Capacitance2 Data')
plt.grid(True)
plt.show()

cap_values = []
with open('Results\\2chips_2channels_single_conversion\cap3_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance3:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance3 (pF)')
plt.title('Capacitance3 Data')
plt.grid(True)
plt.show()