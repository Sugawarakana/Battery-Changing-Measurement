import matplotlib.pyplot as plt
import numpy as np

cap_values = []
with open('Results\\1channel\\cap0_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance0:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance0 (pF)')
plt.title('Capacitance0 Data')
plt.grid(True)
plt.show()

cap_values = []

with open('Results\\2chips\\cap0_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance0:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance0 (pF)')
plt.title('Capacitance0 Data')
plt.grid(True)
plt.show()

cap_values = []

with open('Results\\2chips\\cap1_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance1:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance1 (pF)')
plt.title('Capacitance1 Data')
plt.grid(True)
plt.show()

cap_values = []

with open('Results\\2channels\\cap0_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance0:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance0 (pF)')
plt.title('Capacitance0 Data')
plt.grid(True)
plt.show()

cap_values = []

with open('Results\\2channels\\cap1_data.txt', encoding='utf-8') as f:
    for line in f:
        if 'Capacitance1:' in line:
            value = float(line.split(':')[1].strip())
            cap_values.append(value)

# 计算方差
variance = np.var(cap_values)
print(f"Variance: {variance}")

plt.plot(cap_values, marker='o')
plt.xlabel('Sample Index')
plt.ylabel('Capacitance1 (pF)')
plt.title('Capacitance1 Data')
plt.grid(True)
plt.show()